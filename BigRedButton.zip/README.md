# Lethal Company Big Red Button Mod

Adds a big red button unlockable to the ship in Lethal Company

## Installation

### Requires:

- BepInEx
- Evaisa-HookGenPatcher
- LethalLib


### Instructions

After downloading and installing the required mods,
unzip BigRedButton.zip and place the place the BigRedButton folder 
inside your `Lethal Company\BepInEx\plugins` folder.

